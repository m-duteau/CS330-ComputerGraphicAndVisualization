// Developer:
// Michael Duteau
// 
// Date:
// 25th of February, 2024
// 
// Institution:
// Southern New Hampshire University
// CS-330 Computer Graphic and Visualization
//
// View README.txt for additional information and accredidations

#include "BuildMesh.h"
#include "BuildObject.h"
#include "camera.h"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

using namespace std; // Standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
    const char* const WINDOW_TITLE = "Michael Duteau - CS 330 Final Project: 3D Scene"; // Macro for window title

    // Variables for window width and height
    const int WINDOW_WIDTH = 1200;
    const int WINDOW_HEIGHT = 800;

    // Main GLFW window
    GLFWwindow* gWindow = nullptr;
    // Shape mesh data
    GLMesh gCubeMesh;
    GLMesh gPyramidMesh;
    GLMesh gTrianglePrismMesh;
    GLMesh gRectanglePrismMesh;
    GLMesh gRectanglePrismMesh2;
    GLMesh gPlaneMesh;
    GLMesh gCylinderMesh;
    GLMesh gSphereMesh;
    GLMesh gLeafMesh;
    GLMesh gKeyLightMesh;
    GLMesh gFillLightMesh;

    // Texture IDs
    GLuint gTextureYellowTile;
    GLuint gTextureYellow;
    GLuint gTextureBlack;
    GLuint gTexturePeach;
    GLuint gTextureFace;
    GLuint gTextureGrass;
    GLuint gTextureRubiks1;
    GLuint gTextureRubiks2;
    GLuint gTextureRubiks3;
    GLuint gTextureRubiks4;
    GLuint gTextureFoxOrange;
    GLuint gTextureFoxWhite;
    GLuint gTextureWhiteMarble;
    GLuint gTextureDirt;
    GLuint gTexturePlant;
    GLuint gTextureSky;

    glm::vec2 gUVScale(1.0f, 1.0f);
    GLint gTexWrapMode = GL_REPEAT;

    // Shader program
    GLuint gProgramId;
    GLuint gLightProgramId;

    bool usingOrtho = false;

    // Camera class
    Camera camera(glm::vec3(2.0f, 3.0f, 30.0f));
    float lastX = WINDOW_WIDTH / 2.0f;
    float lastY = WINDOW_HEIGHT / 2.0f;
    bool firstMouse = true;

    // timing
    float deltaTime = 0.0f;
    float lastFrame = 0.0f;

    // Cube color
    glm::vec3 gObjectColor(1.0f, 0.2f, 0.0f);

    // Light color, position, and scale
    glm::vec3 gKeyLightColor(1.0f, 1.0f, 1.0f);
    glm::vec3 gKeyLightPosition(-20.0f, 48.0f, 35.0f);
    glm::vec3 gKeyLightScale(2.5f);

    // Light color, position, and scale
    glm::vec3 gFillLightColor(1.0f, 0.3f, 0.3f);
    glm::vec3 gFillLightPosition(10.0f, -1.5f, -15.0f);
    glm::vec3 gFillLightScale(0.5f);
}

// User-defined Functions
void flipImageVertically(unsigned char* image, int width, int height, int channels);
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void URender();
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);
void UProcessInput(GLFWwindow* window);
void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);

/* Vertex Shader Source Code*/
const GLchar* vertexShaderSource = GLSL(440,
layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
layout(location = 1) in vec3 normal; // VAP position 1 for normals
layout(location = 2) in vec2 textureCoordinate;

out vec3 vertexNormal; // For outgoing normals to fragment shader
out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
out vec2 vertexTextureCoordinate;

//Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

    vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
    vertexTextureCoordinate = textureCoordinate;
}
);


/* Fragment Shader Source Code*/
const GLchar* fragmentShaderSource = GLSL(440,
in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position
in vec2 vertexTextureCoordinate;

out vec4 fragmentColor; // For outgoing cube color to the GPU

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec3 objectColor;
uniform vec3 keyLightColor;
uniform vec3 keyLightPos;
uniform vec3 fillLightColor;
uniform vec3 fillLightPos;
uniform vec3 viewPosition;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform vec2 uvScale;

void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float keyStrength = 1.0;
    float fillStrength = 0.1f;
    vec3 keyLight = keyStrength * keyLightColor;
    vec3 fillLight = fillStrength * fillLightColor;

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 keyLightDirection = normalize(keyLightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    vec3 fillLightDirection = normalize(keyLightPos - vertexFragmentPos);

    float keyImpact = max(dot(norm, keyLightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    float fillImpact = max(dot(norm, fillLightDirection), 0.0);

    vec3 keyDiffuse = keyImpact * keyLightColor; // Generate diffuse light color
    vec3 fillDiffuse = fillImpact * fillLightColor;

    //Calculate Specular lighting*/
    float specularIntensity = 0.8f; // Set specular light strength
    float highlightSize = 16.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-fillLightDirection, norm);// Calculate reflection vector

    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 keySpecular = specularIntensity * specularComponent * keyLightColor;
    vec3 fillSpecular = specularIntensity * specularComponent * fillLightColor;

    // Texture holds the color to be used for all three components
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

    // Calculate phong result
    vec3 phong = (keyLight + fillLight /*+ keyDiffuse*/ + fillDiffuse /*+ keySpecular*/ + fillSpecular) * textureColor.xyz;

    fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
);

/* Lamp Shader Source Code*/
const GLchar* lightVertexShaderSource = GLSL(440,

layout(location = 0) in vec3 position; // VAP position 0 for vertex position data

//Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
}
);


/* Fragment Shader Source Code*/
const GLchar* lightFragmentShaderSource = GLSL(440,

out vec4 fragmentColor; // For outgoing lamp color (smaller cube) to the GPU

void main()
{
    fragmentColor = vec4(1.0f); // Set color to white (1.0f,1.0f,1.0f) with alpha 1.0
}
);

// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so let's flip it
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}

int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // Create shape meshes
    BuildMesh::UCreateCubeMesh(gCubeMesh);
    BuildMesh::UCreatePyramidMesh(gPyramidMesh);
    BuildMesh::UCreateTrianglePrismMesh(gTrianglePrismMesh);
    BuildMesh::UCreateRectanglePrismMesh(gRectanglePrismMesh);
    BuildMesh::UCreateRectanglePrismMesh2(gRectanglePrismMesh2);
    BuildMesh::UCreatePlaneMesh(gPlaneMesh);
    BuildMesh::UCreateCylinderMesh(gCylinderMesh);
    BuildMesh::UCreateSphereMesh(gSphereMesh);
    BuildMesh::UCreateLeafMesh(gLeafMesh);

    // Create light meshes
    BuildMesh::UCreateLightMesh(gKeyLightMesh);
    BuildMesh::UCreateLightMesh(gFillLightMesh);

    // Create the shader program
    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
        return EXIT_FAILURE;

    if (!UCreateShaderProgram(lightVertexShaderSource, lightFragmentShaderSource, gLightProgramId))
        return EXIT_FAILURE;

    // Load duck object textures
    const char* texFilename = "../Final_Project/textures/duck_wool_texture_yellow_tile.png";
    if (!UCreateTexture(texFilename, gTextureYellowTile))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "../Final_Project/textures/duck_wool_texture_yellow.png";
    if (!UCreateTexture(texFilename, gTextureYellow))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "../Final_Project/textures/duck_wool_texture_black.png";
    if (!UCreateTexture(texFilename, gTextureBlack))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "../Final_Project/textures/duck_wool_texture_peach.png";
    if (!UCreateTexture(texFilename, gTexturePeach))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "../Final_Project/textures/duck_wool_texture_face.png";
    if (!UCreateTexture(texFilename, gTextureFace))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }

    // Load grass texture
    texFilename = "../Final_Project/textures/grass_texture_1.png";
    if (!UCreateTexture(texFilename, gTextureGrass))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }

    // Load Rubik's object textures
    texFilename = "../Final_Project/textures/rubiks_1.png";
    if (!UCreateTexture(texFilename, gTextureRubiks1))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "../Final_Project/textures/rubiks_2.png";
    if (!UCreateTexture(texFilename, gTextureRubiks2))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "../Final_Project/textures/rubiks_3.png";
    if (!UCreateTexture(texFilename, gTextureRubiks3))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "../Final_Project/textures/rubiks_4.png";
    if (!UCreateTexture(texFilename, gTextureRubiks4))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }

    // Load fox object textures
    texFilename = "../Final_Project/textures/fox_orange.png";
    if (!UCreateTexture(texFilename, gTextureFoxOrange))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "../Final_Project/textures/fox_white.png";
    if (!UCreateTexture(texFilename, gTextureFoxWhite))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }

    // Load plant object textures
    texFilename = "../Final_Project/textures/white_marble_texture.png";
    if (!UCreateTexture(texFilename, gTextureWhiteMarble))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "../Final_Project/textures/dirt_texture.png";
    if (!UCreateTexture(texFilename, gTextureDirt))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "../Final_Project/textures/plant_texture.png";
    if (!UCreateTexture(texFilename, gTexturePlant))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }

    // Sky texture
    texFilename = "../Final_Project/textures/sky_texture.png";
    if (!UCreateTexture(texFilename, gTextureSky))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }

    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 0);

    // Sets the background color of the window
    glClearColor(0.3f, 0.2f, 0.75f, 1.0f);

    // render loop
    // -----------
    while (!glfwWindowShouldClose(gWindow))
    {
        // per-frame time logic
        // --------------------
        float currentFrame = glfwGetTime();
        deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;

        // input
        // -----
        UProcessInput(gWindow);

        // Render this frame
        URender();

        glfwPollEvents();
    }

    // Release mesh data
    BuildMesh::UDestroyMesh(gCubeMesh);
    BuildMesh::UDestroyMesh(gPyramidMesh);
    BuildMesh::UDestroyMesh(gTrianglePrismMesh);
    BuildMesh::UDestroyMesh(gRectanglePrismMesh);
    BuildMesh::UDestroyMesh(gRectanglePrismMesh2);
    BuildMesh::UDestroyMesh(gPlaneMesh);
    BuildMesh::UDestroyMesh(gKeyLightMesh);
    BuildMesh::UDestroyMesh(gFillLightMesh);
    BuildMesh::UDestroyPiMesh(gCylinderMesh);
    BuildMesh::UDestroyPiMesh(gSphereMesh);
    BuildMesh::UDestroyMesh(gLeafMesh);

    //Release texture data
    UDestroyTexture(gTextureYellowTile);
    UDestroyTexture(gTextureYellow);
    UDestroyTexture(gTextureBlack);
    UDestroyTexture(gTexturePeach);
    UDestroyTexture(gTextureFace);
    UDestroyTexture(gTextureGrass);
    UDestroyTexture(gTextureRubiks1);
    UDestroyTexture(gTextureRubiks2);
    UDestroyTexture(gTextureRubiks3);
    UDestroyTexture(gTextureRubiks4);
    UDestroyTexture(gTextureFoxOrange);
    UDestroyTexture(gTextureFoxWhite);
    UDestroyTexture(gTextureWhiteMarble);
    UDestroyTexture(gTextureDirt);
    UDestroyTexture(gTexturePlant);

    // Release shader program
    UDestroyShaderProgram(gProgramId);
    UDestroyShaderProgram(gLightProgramId);

    exit(EXIT_SUCCESS); // Terminates the program successfully
}


// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);

    glfwSetCursorPosCallback(*window, mouse_callback);
    glfwSetScrollCallback(*window, scroll_callback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // glad: load all OpenGL function pointers
    // ---------------------------------------
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return false;
    }
}


// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}

// Functioned called to render a frame
void URender()
{
    // Enable z-depth
    glEnable(GL_DEPTH_TEST);

    // Clear the frame and z buffers
    glClearColor(0.3f, 0.2f, 0.75f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glm::mat4 scale = glm::scale(glm::vec3(1.0f, 1.0f, 1.0f));
    glm::mat4 rotation = glm::rotate(0.0f, glm::vec3(0.0f, 0.0f, 0.0f));
    glm::mat4 translation = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
    glm::mat4 model = translation * rotation * scale;

    // camera
    glm::mat4 view = camera.GetViewMatrix();

    glm::mat4 projection;

    // view/projection transformations
    if (!usingOrtho)
    {
        // if usingOrtho is false the projection defaults to perspective view
        projection = glm::perspective(glm::radians(camera.Zoom), (float)WINDOW_WIDTH / (float)WINDOW_HEIGHT, 0.1f, 100.0f);
    }
    else
    {
        // orthographic view is used when usingOrtho is true
        projection = glm::ortho(-3.0f, 3.0f, -3.0f, 3.0f, 0.1f, 100.0f);
    }

    // Set the shader to be used
    glUseProgram(gProgramId);

    // Retrieves and passes transform matrices to the Shader program
    GLint modelLoc = glGetUniformLocation(gProgramId, "model");
    GLint viewLoc = glGetUniformLocation(gProgramId, "view");
    GLint projLoc = glGetUniformLocation(gProgramId, "projection");

    //glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));    

    // Reference matrix uniforms from the Cube Shader program for the cub color, light color, light position, and camera position
    GLint objectColorLoc = glGetUniformLocation(gProgramId, "objectColor");

    GLint keyLightColorLoc = glGetUniformLocation(gProgramId, "keyLightColor");
    GLint keyLightPositionLoc = glGetUniformLocation(gProgramId, "keyLightPos");

    GLint fillLightColorLoc = glGetUniformLocation(gProgramId, "fillLightColor");
    GLint fillLightPositionLoc = glGetUniformLocation(gProgramId, "fillLightPos");

    GLint viewPositionLoc = glGetUniformLocation(gProgramId, "viewPosition");

    // Pass color, light, and camera data to the Cube Shader program's corresponding uniforms
    glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);

    glUniform3f(keyLightColorLoc, gKeyLightColor.r, gKeyLightColor.g, gKeyLightColor.b);
    glUniform3f(keyLightPositionLoc, gKeyLightPosition.x, gKeyLightPosition.y, gKeyLightPosition.z);

    glUniform3f(fillLightColorLoc, gFillLightColor.r, gFillLightColor.g, gFillLightColor.b);
    glUniform3f(fillLightPositionLoc, gFillLightPosition.x, gFillLightPosition.y, gFillLightPosition.z);

    const glm::vec3 cameraPosition = camera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    GLint UVScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    /*********************************************************************************************************************
    *                                                Object Building                                                     *
    *********************************************************************************************************************/
    BuildObject::UBuildDuck(gCubeMesh, gPyramidMesh, gTrianglePrismMesh, gRectanglePrismMesh, gRectanglePrismMesh2,
        gTextureYellow, gTextureBlack, gTexturePeach, gTextureFace, modelLoc);

    BuildObject::UBuildRubiksCube(gCubeMesh, gTextureRubiks1, gTextureRubiks2, gTextureRubiks3, gTextureRubiks4, modelLoc);
    
    BuildObject::UBuildFox(gSphereMesh, gTrianglePrismMesh, gTextureFoxOrange, gTextureFoxWhite, gTextureBlack, modelLoc);

    BuildObject::UBuildPlant(gCylinderMesh, gLeafMesh, gTextureWhiteMarble, gTextureDirt, gTexturePlant, modelLoc);

    BuildObject::UBuildGround(gPlaneMesh, gTextureGrass, modelLoc);

    BuildObject::UBuildSky(gCubeMesh, gTextureSky, modelLoc);


    /**********************************************************************
    *                           Light Objects                             *
    **********************************************************************/
    glUseProgram(gLightProgramId);

    //key light
    glBindVertexArray(gKeyLightMesh.vao);

    //Transform the smaller cube used as a visual que for the light source
    model = glm::translate(gKeyLightPosition) * glm::scale(gKeyLightScale);

    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gLightProgramId, "model");
    viewLoc = glGetUniformLocation(gLightProgramId, "view");
    projLoc = glGetUniformLocation(gLightProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    glDrawArrays(GL_TRIANGLES, 0, gKeyLightMesh.nVertices);

    //fill light
    glBindVertexArray(gFillLightMesh.vao);

    //Transform the smaller cube used as a visual que for the light source
    model = glm::translate(gFillLightPosition) * glm::scale(gFillLightScale);

    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gLightProgramId, "model");
    viewLoc = glGetUniformLocation(gLightProgramId, "view");
    projLoc = glGetUniformLocation(gLightProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    glDrawArrays(GL_TRIANGLES, 0, gFillLightMesh.nVertices);

    glBindVertexArray(0);

    // Deactivate the shader program   
    glUseProgram(0);

    // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.
}

// Implements UCreateTexture function
bool UCreateTexture(const char* filename, GLuint& textureId)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // Set texture filtering parameters.
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture.

        return true;
    }

    // Error loading the image
    return false;
}

void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}

// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
}


void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
void UProcessInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        camera.ProcessKeyboard(FORWARD, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        camera.ProcessKeyboard(BACKWARD, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        camera.ProcessKeyboard(LEFT, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        camera.ProcessKeyboard(RIGHT, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        camera.ProcessKeyboard(UP, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        camera.ProcessKeyboard(DOWN, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
        usingOrtho = false;
    if (glfwGetKey(window, GLFW_KEY_O) == GLFW_PRESS)
        usingOrtho = true;
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    // make sure the viewport matches the new window dimensions; note that width and 
    // height will be significantly larger than specified on retina displays.
    glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
    if (firstMouse)
    {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }

    float xoffset = xpos - lastX;
    float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top

    lastX = xpos;
    lastY = ypos;

    camera.ProcessMouseMovement(xoffset, yoffset);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    camera.ProcessMouseScroll(yoffset);
}