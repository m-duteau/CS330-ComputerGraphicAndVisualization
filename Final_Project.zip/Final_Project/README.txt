Description:

When run, the program renders a 3D scene that displays 4 main objects which are referenced from the proposal
image for this project, which contains four objects I own: a Rubik's Cube, a mini Psyduck (from Pok�mon)
lego figure, a fox plush, and a potted plant

The objects were created using OpenGL by creating meshes of different 3D and 2D shapes, combining them in
order to simulate the objects in the original image

The objects are placed on a plane object with a grass texture and background color set to blue with
slight red tinge to simulate an open field at sunset

Key light is the main source of light acting as the scene's "sun", colored white to maintain its clarity
Fill light is hidden under the plane with low intensity red light in order to add minor reddish/orangeish
hue to the scene in order to further simulate that the scene takes place at sunset

*

Notes:

This project uses code from a prior project assignment_6_5.cpp as a baseline

Uses WASD controls with Q and E for vertical movement; W: Forward, S: Backward, A: Left, D: Right, Q: Up, E: Down

Use mouse movement to manipulate the camera view/angles

Scroll mouse wheel forward to speed up WASD movement, scroll backward to slow

Pressing O will trigger orthographic view, Pressing P will re-trigger perspective view

*

Self-made texture files:

Textures applied to "duck" are a picture that I took of a sweater I own to give the object a "wool" texture

The texture files of this sweater consist of images that modify the base gTextureYellow source image's
hue/saturation/brightness/contrast using GIMP image editing software

Textures applied to "Rubik's Cube" are pictures of the Rubik's Cube's different faces from the project
proposal reference image

Textures applied to "fox" are pictures of the fox plush from the project proposal reference image

*

Credits:

Grass texture  .png: https://www.deviantart.com/fabooguy/art/Grass-Texture-Tileable-2048x2048-432223599
Dirt texture  .png: https://www.deviantart.com/fabooguy/art/Dirt-Ground-Texture-Tileable-2048x2048-441212191
free use with given credit per CC license and creator FabooGuy

Marble texture  .png: https://opengameart.org/content/4k-seamless-white-marble-stone-textures-public-domain
"Totally Free with no Attribution Required" per creator Behrtron

Plant texture  .png: https://www.deviantart.com/enchantedgal-stock/art/Olive-Green-Paper-Background-49513200
"You have permission to use this image in your digital art" per creator Enchantedgal-Stock

Sky texture  .png: https://www.deviantart.com/aozametaneko/art/Seamless-Sky-Texture-391651945
No notes on useage, creator aozametaneko notes on other works "free for any use"
Texture can be removed per creator's request

UCreateSphereMesh and UCreateCylinderMesh AUTHOR: Brian Battersby - SNHU Instructor / Computer Science 

*

Disclaimer:

This project is an academic project for Southern New Hampshire University's CS-330 Computer Graphic and
Visualization course and is not authorized for commercial distribution