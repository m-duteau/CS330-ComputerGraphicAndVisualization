#include "BuildObject.h"

glm::mat4 scale = glm::scale(glm::vec3(1.0f, 1.0f, 1.0f));
glm::mat4 rotation = glm::rotate(0.0f, glm::vec3(1.0f, 1.0f, 1.0f));
glm::mat4 translation = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
glm::mat4 model = translation * rotation * scale;

void BuildObject::UBuildDuck(GLMesh cubeMesh, GLMesh pyramidMesh, GLMesh triPrismMesh, GLMesh recPrismMesh1, GLMesh recPrismMesh2,
	GLuint textureYellow,GLuint textureBlack, GLuint texturePeach, GLuint textureFace, GLint modelLoc)
{
    scale = glm::scale(glm::vec3(1.0f, 1.0f, 1.0f));
    rotation = glm::rotate(0.0f, glm::vec3(0.0f, 1.0f, 0.0f));
    translation = glm::translate(glm::vec3(-1.5f, 0.6f, 0.0f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // *HEAD/BODY
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(cubeMesh.vao);

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, textureYellow);

    // Draws body
    glDrawArrays(GL_TRIANGLES, 0, cubeMesh.nVertices);

    scale = glm::scale(glm::vec3(1.0f, 1.0f, 1.0f));
    translation = glm::translate(glm::vec3(-1.5f, 1.65f, 0.0f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws head
    glDrawArrays(GL_TRIANGLES, 0, 6);
    glBindTexture(GL_TEXTURE_2D, textureFace);
    glDrawArrays(GL_TRIANGLES, 6, 6);
    glBindTexture(GL_TEXTURE_2D, textureYellow);
    glDrawArrays(GL_TRIANGLES, 6, cubeMesh.nVertices);

    glBindVertexArray(0);

    // *ARMS/TAIL
    glBindVertexArray(pyramidMesh.vao);

    scale = glm::scale(glm::vec3(0.5f, 0.5f, 0.5f));
    translation = glm::translate(glm::vec3(-0.8f, 0.8f, 0.0f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws left arm
    glDrawArrays(GL_TRIANGLES, 0, pyramidMesh.nVertices);

    scale = glm::scale(glm::vec3(0.5f, 0.5f, 0.5f));
    rotation = glm::rotate(3.14159265359f, glm::vec3(0.0f, 1.0f, 0.0f));
    translation = glm::translate(glm::vec3(-2.2f, 0.8f, 0.0f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws right arm
    glDrawArrays(GL_TRIANGLES, 0, pyramidMesh.nVertices);

    scale = glm::scale(glm::vec3(0.3f, 0.3f, 0.3f));
    rotation = glm::rotate(1.57079632679f, glm::vec3(0.0f, 1.0f, 0.0f));
    translation = glm::translate(glm::vec3(-1.5f, 0.4f, -0.6f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws tail
    glDrawArrays(GL_TRIANGLES, 0, pyramidMesh.nVertices);

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    // *BEAK
    glBindVertexArray(triPrismMesh.vao);

    glBindTexture(GL_TEXTURE_2D, texturePeach);

    scale = glm::scale(glm::vec3(0.5f, 0.5f, 0.8f));
    rotation = glm::rotate(0.0f, glm::vec3(0.0f, 1.0f, 0.0f));
    translation = glm::translate(glm::vec3(-1.5f, 1.5f, 0.8f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws beak
    glDrawArrays(GL_TRIANGLES, 0, triPrismMesh.nVertices);

    glBindVertexArray(0);

    // *HAIR
    glBindVertexArray(recPrismMesh1.vao);

    glBindTexture(GL_TEXTURE_2D, textureBlack);

    scale = glm::scale(glm::vec3(0.3f, 0.3f, 0.3f));
    rotation = glm::rotate(0.0f, glm::vec3(0.0f, 1.0f, 0.0f));
    translation = glm::translate(glm::vec3(-1.5f, 2.3f, 0.0f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws horizontal hair thing
    glDrawArrays(GL_TRIANGLES, 0, recPrismMesh1.nVertices);

    scale = glm::scale(glm::vec3(0.3f, 0.3f, 0.3f));
    rotation = glm::rotate(1.57079632679f, glm::vec3(0.0f, 0.0f, 1.0f));
    translation = glm::translate(glm::vec3(-1.5f, 2.3f, 0.0f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws vertical hair thing
    glDrawArrays(GL_TRIANGLES, 0, recPrismMesh1.nVertices);

    glBindVertexArray(0);

    // *NECK/FEET
    glBindVertexArray(recPrismMesh2.vao);

    glBindTexture(GL_TEXTURE_2D, texturePeach);

    scale = glm::scale(glm::vec3(0.6f, 0.6f, 0.6f));
    rotation = glm::rotate(0.0f, glm::vec3(0.0f, 0.0f, 1.0f));
    translation = glm::translate(glm::vec3(-1.5f, 1.1f, 0.0f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws neck
    glDrawArrays(GL_TRIANGLES, 0, recPrismMesh2.nVertices);

    scale = glm::scale(glm::vec3(0.3f, 0.3f, 0.3f));
    translation = glm::translate(glm::vec3(-1.8f, 0.05f, 0.4f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws right foot
    glDrawArrays(GL_TRIANGLES, 0, recPrismMesh2.nVertices);

    scale = glm::scale(glm::vec3(0.3f, 0.3f, 0.3f));
    translation = glm::translate(glm::vec3(-1.2f, 0.05f, 0.4f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws left foot
    glDrawArrays(GL_TRIANGLES, 0, recPrismMesh2.nVertices);

    glBindTexture(GL_TEXTURE_2D, 0);
    glBindVertexArray(0);
}

void BuildObject::UBuildRubiksCube(GLMesh cubeMesh, GLuint textureRubiks1, GLuint textureRubiks2, GLuint textureRubiks3, GLuint textureRubiks4, GLint modelLoc)
{
    glBindVertexArray(cubeMesh.vao);

    glBindTexture(GL_TEXTURE_2D, textureRubiks2);

    scale = glm::scale(glm::vec3(2.5f, 2.5f, 2.5f));
    translation = glm::translate(glm::vec3(-7.5f, 1.4f, 0.3f));
    rotation = glm::rotate(0.523599f, glm::vec3(0.0f, 1.0f, 0.0f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws the cube
    glDrawArrays(GL_TRIANGLES, 0, 6);
    glBindTexture(GL_TEXTURE_2D, textureRubiks1);
    glDrawArrays(GL_TRIANGLES, 6, 6);
    glBindTexture(GL_TEXTURE_2D, textureRubiks4);
    glDrawArrays(GL_TRIANGLES, 6, 18);
    glBindTexture(GL_TEXTURE_2D, textureRubiks3);
    glDrawArrays(GL_TRIANGLES, 18, 18);
    glDrawArrays(GL_TRIANGLES, 18, cubeMesh.nVertices);

    glBindTexture(GL_TEXTURE_2D, 0);
    glBindVertexArray(0);
}

void BuildObject::UBuildFox(GLMesh sphereMesh, GLMesh triPrismMesh, GLuint textureFoxOrange, GLuint textureFoxWhite, GLuint textureBlack, GLint modelLoc)
{
    glBindVertexArray(sphereMesh.vao);

    glBindTexture(GL_TEXTURE_2D, textureFoxOrange);

    // *HEAD/BODY
    scale = glm::scale(glm::vec3(1.0f, 1.5f, 1.0f));
    translation = glm::translate(glm::vec3(4.2f, 1.0f, 0.5f));
    rotation = glm::rotate(0.0f, glm::vec3(0.0f, 1.0f, 0.0f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Body
    glDrawArrays(GL_TRIANGLE_FAN, sphereMesh.vbos[0], sphereMesh.nVertices);

    scale = glm::scale(glm::vec3(1.4f, 1.0f, 1.0f));
    translation = glm::translate(glm::vec3(4.2f, 2.6f, 0.5f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Head
    glDrawArrays(GL_TRIANGLE_FAN, sphereMesh.vbos[0], sphereMesh.nVertices);

    // *ARMS/TAIL
    scale = glm::scale(glm::vec3(0.3f, 0.9f, 0.3f));
    translation = glm::translate(glm::vec3(3.05f, 1.55f, 0.5f));
    rotation = glm::rotate(2.0f, glm::vec3(1.0f, -0.8f, 1.0f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Right arm
    glDrawArrays(GL_TRIANGLE_FAN, sphereMesh.vbos[0], sphereMesh.nVertices);

    translation = glm::translate(glm::vec3(5.4f, 1.55f, 0.5f));
    rotation = glm::rotate(2.0f, glm::vec3(1.0f, 0.8f, -1.0f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Left arm
    glDrawArrays(GL_TRIANGLE_FAN, sphereMesh.vbos[0], sphereMesh.nVertices);

    translation = glm::translate(glm::vec3(4.1f, 0.4f, -0.7f));
    rotation = glm::rotate(2.0f, glm::vec3(-0.7f, 0.8f, -0.8f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Tail
    glDrawArrays(GL_TRIANGLE_FAN, sphereMesh.vbos[0], sphereMesh.nVertices);

    // *LEGS
    scale = glm::scale(glm::vec3(0.4f, 0.95f, 0.4f));
    translation = glm::translate(glm::vec3(3.15f, 0.35f, 1.1f));
    rotation = glm::rotate(2.2f, glm::vec3(1.0f, -0.8f, -0.1f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Right leg
    glDrawArrays(GL_TRIANGLE_FAN, sphereMesh.vbos[0], sphereMesh.nVertices);

    translation = glm::translate(glm::vec3(5.15f, 0.35f, 1.1f));
    rotation = glm::rotate(2.2f, glm::vec3(1.0f, 0.8f, 0.1f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Left leg
    glDrawArrays(GL_TRIANGLE_FAN, sphereMesh.vbos[0], sphereMesh.nVertices);

    // *BELLY/MOUTH
    glBindTexture(GL_TEXTURE_2D, textureFoxWhite);

    scale = glm::scale(glm::vec3(0.8f, 0.8f, 0.4f));
    translation = glm::translate(glm::vec3(4.2f, 1.0f, 1.2f));
    rotation = glm::rotate(0.0f, glm::vec3(1.0f, 1.0f, 1.0f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Belly
    glDrawArrays(GL_TRIANGLE_FAN, sphereMesh.vbos[0], sphereMesh.nVertices);

    scale = glm::scale(glm::vec3(0.8f, 0.4f, 0.4f));
    translation = glm::translate(glm::vec3(4.2f, 2.3f, 1.3f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Mouth/muzzle
    glDrawArrays(GL_TRIANGLE_FAN, sphereMesh.vbos[0], sphereMesh.nVertices);

    // *NOSE/EYES
    glBindTexture(GL_TEXTURE_2D, textureBlack);

    scale = glm::scale(glm::vec3(0.2f, 0.2f, 0.2f));
    translation = glm::translate(glm::vec3(4.2f, 2.7f, 1.45f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Nose
    glDrawArrays(GL_TRIANGLE_FAN, sphereMesh.vbos[0], sphereMesh.nVertices);

    scale = glm::scale(glm::vec3(0.1f, 0.1f, 0.1f));
    translation = glm::translate(glm::vec3(3.7f, 3.0f, 1.3f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Right eye
    glDrawArrays(GL_TRIANGLE_FAN, sphereMesh.vbos[0], sphereMesh.nVertices);

    translation = glm::translate(glm::vec3(4.7f, 3.0f, 1.3f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Left eye
    glDrawArrays(GL_TRIANGLE_FAN, sphereMesh.vbos[0], sphereMesh.nVertices);

    glBindVertexArray(0);

    // Ears
    glBindVertexArray(triPrismMesh.vao);

    glBindTexture(GL_TEXTURE_2D, textureFoxOrange);

    scale = glm::scale(glm::vec3(0.7f, 0.7f, 0.7f));
    rotation = glm::rotate(-1.57079632679f, glm::vec3(1.0f, 0.0f, 0.4f));
    translation = glm::translate(glm::vec3(4.9f, 3.6f, 0.6f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws left ear
    glDrawArrays(GL_TRIANGLES, 0, 21);
    glBindTexture(GL_TEXTURE_2D, textureFoxWhite);
    glDrawArrays(GL_TRIANGLES, 21, triPrismMesh.nVertices);

    rotation = glm::rotate(-1.57079632679f, glm::vec3(1.0f, 0.0f, -0.4f));
    translation = glm::translate(glm::vec3(3.5f, 3.6f, 0.6f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws right ear
    glBindTexture(GL_TEXTURE_2D, textureFoxOrange);
    glDrawArrays(GL_TRIANGLES, 0, 21);
    glBindTexture(GL_TEXTURE_2D, textureFoxWhite);
    glDrawArrays(GL_TRIANGLES, 21, triPrismMesh.nVertices);

    glBindTexture(GL_TEXTURE_2D, 0);
    glBindVertexArray(0);
}

void BuildObject::UBuildPlant(GLMesh cylinderMesh, GLMesh leafMesh, GLuint textureWhiteMarble, GLuint textureDirt, GLuint texturePlant, GLint modelLoc)
{
    glBindVertexArray(cylinderMesh.vao);

    glBindTexture(GL_TEXTURE_2D, textureWhiteMarble);

    scale = glm::scale(glm::vec3(2.5f, 3.5f, 2.5f));
    translation = glm::translate(glm::vec3(12.5f, 0.01f, 4.0));
    rotation = glm::rotate(0.0f, glm::vec3(0.0f, 1.0f, 0.0f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws pot
    // bottom
    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);
    // top
    glBindTexture(GL_TEXTURE_2D, textureDirt);
    glDrawArrays(GL_TRIANGLE_FAN, 37, 36);
    //sides
    glBindTexture(GL_TEXTURE_2D, textureWhiteMarble);
    glDrawArrays(GL_TRIANGLE_STRIP, 74, cylinderMesh.nVertices);

    glBindTexture(GL_TEXTURE_2D, texturePlant);

    scale = glm::scale(glm::vec3(0.1f, 7.0f, 0.1f));
    translation = glm::translate(glm::vec3(12.7f, 3.5f, 4.2f));
    rotation = glm::rotate(0.1f, glm::vec3(1.0f, 0.0f, 0.0f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws base stem 1
    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);
    glDrawArrays(GL_TRIANGLE_FAN, 37, 36);
    glDrawArrays(GL_TRIANGLE_STRIP, 74, cylinderMesh.nVertices);

    translation = glm::translate(glm::vec3(12.3f, 3.5f, 3.8f));
    rotation = glm::rotate(-0.1f, glm::vec3(1.0f, 0.0f, 0.0f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws base stem 2
    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);
    glDrawArrays(GL_TRIANGLE_FAN, 37, 36);
    glDrawArrays(GL_TRIANGLE_STRIP, 74, cylinderMesh.nVertices);

    // Branching stems
    scale = glm::scale(glm::vec3(0.05f, 4.0f, 0.05f));
    translation = glm::translate(glm::vec3(12.3f, 7.5f, 3.45f));
    rotation = glm::rotate(1.7708f, glm::vec3(1.0f, 0.0f, 1.5f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);
    glDrawArrays(GL_TRIANGLE_FAN, 37, 36);
    glDrawArrays(GL_TRIANGLE_STRIP, 74, cylinderMesh.nVertices);

    translation = glm::translate(glm::vec3(12.3f, 8.5f, 3.3f));
    rotation = glm::rotate(-1.308f, glm::vec3(-0.3f, 0.0f, 1.0f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);
    glDrawArrays(GL_TRIANGLE_FAN, 37, 36);
    glDrawArrays(GL_TRIANGLE_STRIP, 74, cylinderMesh.nVertices);

    translation = glm::translate(glm::vec3(12.75f, 8.2f, 4.7f));
    rotation = glm::rotate(-1.008f, glm::vec3(-0.1f, 0.0f, -1.0f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);
    glDrawArrays(GL_TRIANGLE_FAN, 37, 36);
    glDrawArrays(GL_TRIANGLE_STRIP, 74, cylinderMesh.nVertices);

    translation = glm::translate(glm::vec3(12.7f, 7.7f, 4.6f));
    rotation = glm::rotate(1.7708f, glm::vec3(1.0f, 0.0f, 0.0f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);
    glDrawArrays(GL_TRIANGLE_FAN, 37, 36);
    glDrawArrays(GL_TRIANGLE_STRIP, 74, cylinderMesh.nVertices);

    glBindVertexArray(0);

    // Leaves
    glBindVertexArray(leafMesh.vao);

    scale = glm::scale(glm::vec3(1.0f, 1.0f, 1.0f));
    translation = glm::translate(glm::vec3(10.85f, 6.75f, 3.8f));
    rotation = glm::rotate(-1.5708f, glm::vec3(0.0f, 1.5f, 1.0f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glDrawArrays(GL_TRIANGLES, 0, leafMesh.nVertices);

    translation = glm::translate(glm::vec3(10.2f, 6.4f, 5.5f));
    rotation = glm::rotate(1.5708f, glm::vec3(0.0f, -1.5f, 1.0f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glDrawArrays(GL_TRIANGLES, 0, leafMesh.nVertices);

    translation = glm::translate(glm::vec3(12.05f, 6.9f, 7.5f));
    rotation = glm::rotate(1.5708f, glm::vec3(1.0f, 0.8f, -1.0f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glDrawArrays(GL_TRIANGLES, 0, leafMesh.nVertices);

    translation = glm::translate(glm::vec3(13.4f, 7.45f, 6.3));
    rotation = glm::rotate(-2.0708f, glm::vec3(-1.0f, 0.8f, -1.0f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glDrawArrays(GL_TRIANGLES, 0, leafMesh.nVertices);

    translation = glm::translate(glm::vec3(14.9f, 9.1f, 4.8));
    rotation = glm::rotate(-1.5708f, glm::vec3(1.5f, 0.8f, -0.3f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glDrawArrays(GL_TRIANGLES, 0, leafMesh.nVertices);

    translation = glm::translate(glm::vec3(13.2f, 8.5f, 2.9));
    rotation = glm::rotate(1.2708f, glm::vec3(1.0f, -0.2f, -0.2f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glDrawArrays(GL_TRIANGLES, 0, leafMesh.nVertices);

    translation = glm::translate(glm::vec3(10.2f, 9.3f, 4.4));
    rotation = glm::rotate(0.8708f, glm::vec3(1.0f, -0.2f, -0.2f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glDrawArrays(GL_TRIANGLES, 0, leafMesh.nVertices);

    translation = glm::translate(glm::vec3(11.9f, 8.35f, 5.3));
    rotation = glm::rotate(-0.8708f, glm::vec3(1.0f, -0.2f, -0.2f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glDrawArrays(GL_TRIANGLES, 0, leafMesh.nVertices);

    glBindTexture(GL_TEXTURE_2D, 0);
    glBindVertexArray(0);
}

void BuildObject::UBuildGround(GLMesh planeMesh, GLuint textureGrass, GLint modelLoc)
{
    glBindVertexArray(planeMesh.vao);

    glBindTexture(GL_TEXTURE_2D, textureGrass);

    scale = glm::scale(glm::vec3(100.0f, 100.0f, 100.0f));
    rotation = glm::rotate(0.0f, glm::vec3(0.0f, 1.0f, 0.0f));
    translation = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws the plane
    glDrawArrays(GL_TRIANGLES, 0, planeMesh.nVertices);

    glBindTexture(GL_TEXTURE_2D, 0);
    glBindVertexArray(0);
}

void BuildObject::UBuildSky(GLMesh cubeMesh, GLuint textureSky, GLint modelLoc)
{
    glBindVertexArray(cubeMesh.vao);

    glBindTexture(GL_TEXTURE_2D, textureSky);

    scale = glm::scale(glm::vec3(100.00f, 100.00f, 100.00f));
    translation = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
    rotation = glm::rotate(0.0f, glm::vec3(1.0f, 1.0f, 1.0f));
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws the cube
    glDrawArrays(GL_TRIANGLES, 0, cubeMesh.nVertices);

    glBindTexture(GL_TEXTURE_2D, 0);
    glBindVertexArray(0);
}