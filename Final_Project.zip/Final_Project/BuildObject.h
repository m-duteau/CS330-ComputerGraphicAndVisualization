#ifndef BUILDOBJECT_H_
#define BUILDOBJECT_H_

#include "BuildMesh.h"

extern glm::mat4 scale;
extern glm::mat4 rotation;
extern glm::mat4 translation;
extern glm::mat4 model;

class BuildObject 
{
public:
	static void UBuildDuck(GLMesh cubeMesh, GLMesh pyramidMesh, GLMesh triPrismMesh, GLMesh recPrismMesh1, GLMesh recPrismMesh2,
		GLuint textureYellow, GLuint textureBlack, GLuint texturePeach, GLuint textureFace, GLint modelLoc);
	static void UBuildRubiksCube(GLMesh cubeMesh, GLuint textureRubiks1, GLuint textureRubiks2, GLuint textureRubiks3, GLuint textureRubiks4, GLint modelLoc);
	static void UBuildFox(GLMesh sphereMesh, GLMesh triPrismMesh, GLuint textureFoxOrange, GLuint textureFoxWhite, GLuint textureBlack, GLint modelLoc);
	static void UBuildPlant(GLMesh cylinderMesh, GLMesh leafMesh, GLuint textureWhiteMarble, GLuint textureDirt, GLuint texturePlant, GLint modelLoc);
	static void UBuildGround(GLMesh planeMesh, GLuint textureGrass, GLint modelLoc);
	static void UBuildSky(GLMesh cubeMesh, GLuint textureSky, GLint modelLoc);
};

#endif