#ifndef BUILDMESH_H_
#define BUILDMESH_H_

#include <iostream>
#include <cstdlib>
#include <vector>

#include <glad/glad.h>
#include <GLFW/glfw3.h>     // GLFW library

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

struct GLMesh
{
	GLuint vao;         // Handle for the vertex array object
	GLuint vbo;         // Handles for the vertex buffer objects
	GLuint vbos[2];		// Extra vbo handling
	GLuint nVertices;   // Number of vertices of the mesh
	GLuint nIndices;	// Number of indices of the mesh
};

class BuildMesh
{
public:
	static void UCreateCubeMesh(GLMesh& mesh);
	static void UCreatePyramidMesh(GLMesh& mesh);
	static void UCreateTrianglePrismMesh(GLMesh& mesh);
	static void UCreateRectanglePrismMesh(GLMesh& mesh);
	static void UCreateRectanglePrismMesh2(GLMesh& mesh);
	static void UCreatePlaneMesh(GLMesh& mesh);
	static void UCreateCylinderMesh(GLMesh& mesh);
	static void UCreateSphereMesh(GLMesh& mesh);
	static void UCreateLeafMesh(GLMesh& mesh);
	static void UCreateLightMesh(GLMesh& mesh);
	static void UDestroyMesh(GLMesh& mesh);	
	static void UDestroyPiMesh(GLMesh& mesh);

private:
	static void SetMesh(GLMesh& mesh, GLfloat verts[], int size);
};

#endif
